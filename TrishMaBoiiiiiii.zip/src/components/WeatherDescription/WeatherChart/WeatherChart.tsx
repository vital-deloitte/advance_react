import React, { useEffect } from "react";
import "./WeatherChart.scss";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Filler,
  Legend,
} from "chart.js";

import { Line } from "react-chartjs-2";
import { useDispatch, useSelector } from "react-redux";
import {
  ChartDataType,
  ChartType,
} from "../../assets/WeatherInterfaces/chartTypes";
import axios, { AxiosResponse } from "axios";
import { APP_KEY } from "../../assets/Constants";
import { weatherChartAction } from "../../../store/store";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Filler,
  Legend
);

export const options = {
  responsive: true,
};

function WeatherChart({ cityName }: { cityName: string }) {
  const chartData = useSelector((state: ChartDataType) => state.chartData);
  const dispatch = useDispatch();
  const dataDisplay = chartData.data;

  const labels: Array<String> = [];
  const temperatures: Array<number> = [];

  dataDisplay.forEach((reading) => {
    temperatures.push(reading.main.temp);
  });

  dataDisplay.forEach((reading) => {
    labels.push(new Date(reading.dt * 1000).toDateString());
  });

  useEffect(() => {
    const forecastUrl = `http://api.openweathermap.org/data/2.5/forecast?q=${cityName}&appid=${APP_KEY}`;
    axios.get(forecastUrl).then((response: AxiosResponse) => {
      const result: ChartType = {
        data: response.data.list,
      };
      dispatch(weatherChartAction.populateArray(result.data));
      return result;
    });
  }, [cityName, dispatch]);

  const data = {
    labels,
    datasets: [
      {
        fill: true,
        label: "Sunrise",
        data: temperatures,
        borderColor: "rgb(53, 162, 235)",
        backgroundColor: "rgba(53, 162, 235, 0.5)",
      },
    ],
  };

  return (
    <div className="bottom-container container pt-4">
      <div className="row chart-details justify-content-center pt-4">
        <div className="col-sm-5">
          <p className="main-title">
            SUNRISE &#38; SUNSET
          </p>
          <div className="col-12 d-block d-sm-none pb-2">
            <Line data={data} options={options} />
          </div>
          <p className="day-length ">
            Length of day: <span style={{ color: "#2C2C2C" }}>13H 12M</span>
          </p>
          <p className="remaining-length">
            Remaining daylight: <span style={{ color: "#2C2C2C" }}>9H 22M</span>
          </p>
        </div>
        <div className="col-sm-6 d-none d-sm-block">
          <Line data={data} options={options} />
        </div>
      </div>
    </div>
  );
}

export default WeatherChart;
