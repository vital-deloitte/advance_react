export const iconUrl = "https://openweathermap.org/img/wn/";
export const APP_KEY = "89b0bdbc5a5822893ec6db298e814fad"