export const iconUrl = "https://openweathermap.org/img/wn/";
